<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>alert popup</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="build/js/bundle-ae10cb0641.js"></script>
        <!-- <link rel="stylesheet" href="css/alertify.min.css">
        <link rel="stylesheet" href="css/themes/default.min.css"> -->
        <link rel="stylesheet" href="build/css/stylesheet-2648e68a93.css">
        <style>
        </style>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <h1>alert popup</h1>
        <input id="clickMe" type="button" value="start again" onclick="alert();" />
        <!-- <script>
        var content='<div class="badge"><div class="badge_img"><img src="img/map.png" alt=""></div><div class="badge_text"><div class="badge_text_title">John Snow</div><div class="badge_text_1">Recently signed up from Italy</div><div class="badge_text_1">an hour ago</div></div>';
        var content_2='<div class="badge"><div class="badge_img"><img src="img/user.png" alt=""></div><div class="badge_text"><div class="badge_text_title">Kalisi</div><div class="badge_text_1">Recently signed up from Italy</div><div class="badge_text_1">an hour ago</div></div>';
        
        function alert(){
            alertify.set('notifier', 'position' , 'bottom-left');
            var notification= alertify.success(content_2,5);
                notification.ondismiss = function(){ 
                var notification_2=alertify.success(content,5); 
                }
            setTimeout(alert,000);
        }
        alert();
        </script> -->
    </body>
</html>