var cnt='<div class="badge"><div class="badge_img"><img src="http://www.danielecolpo.it/fbb/img/map.png" alt=""></div><div class="badge_text"><div class="badge_text_title">John Snow</div><div class="badge_text_1">Recently signed up from Italy</div><div class="badge_text_1">an hour ago</div></div>';
var cnt_2='<div class="badge"><div class="badge_img"><img src="http://www.danielecolpo.it/fbb/img/user.png" alt=""></div><div class="badge_text"><div class="badge_text_title">Kalisi</div><div class="badge_text_1">Recently signed up from Italy</div><div class="badge_text_1">an hour ago</div></div>';
function fbocci(){
    alertify.set('notifier', 'position' , 'bottom-left');
    var notification= alertify.success(cnt_2,5);
        notification.ondismiss = function(){ 
        var notification_2=alertify.success(cnt,5);
        } 
    setTimeout(fbocci,10000);

}
window.onload = fbocci;